# Tugas5-MobileComputing
 
