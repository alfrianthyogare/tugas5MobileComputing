package com.example.tugas5mobilecomputing_alfrianthyogare;

public class Myitem {
    static int[] poster = {
            R.drawable.new_poster_1, R.drawable.new_poster_2, R.drawable.new_poster_3,
            R.drawable.new_poster_4, R.drawable.new_poster_5
    };

    static String[] judulBerita = {
            "Rakyat Nusa Tenggara Timur Menang", "Peduli Kasih: Pembangunan Gereja Salib Suci Maurole NTT",
            "Kampung: 3 Kampung Adat Terpopuler", "Peduli Bencana NTT",
            "Wulla Podu: Ritual Sakral Masyarakat Sumba Barat"

    };

    static String[] tahunBerita = {
            "2022", "2021", "2021",
            "2021", "2017"
    };
}
