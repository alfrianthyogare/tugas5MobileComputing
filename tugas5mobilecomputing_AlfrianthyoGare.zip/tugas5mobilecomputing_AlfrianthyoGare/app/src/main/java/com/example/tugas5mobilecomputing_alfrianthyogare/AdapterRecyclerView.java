package com.example.tugas5mobilecomputing_alfrianthyogare;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterRecyclerView extends RecyclerView.Adapter<AdapterRecyclerView.ViewHolder> {

    ArrayList<itemModel> dataItem;

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView textJudul;
        TextView textTahun;
        ImageView posterBerita;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textJudul = itemView.findViewById(R.id.text_judul);
            textTahun = itemView.findViewById(R.id.text_tahun);
            posterBerita = itemView.findViewById(R.id.image_poster);
        }
    }


    AdapterRecyclerView (ArrayList<itemModel> data) {
        this.dataItem = data;
    }

    @NonNull
    @Override
    public AdapterRecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterRecyclerView.ViewHolder holder, int position) {

        TextView text_judul = holder.textJudul;
        TextView text_tahun = holder.textTahun;
        ImageView iamge_poster = holder.posterBerita;

        text_judul.setText(dataItem.get(position).getName());
        text_tahun.setText(dataItem.get(position).getYear());
        iamge_poster.setImageResource(dataItem.get(position).getPoster());
    }

    @Override
    public int getItemCount() {
        return dataItem.size();
    }


}
